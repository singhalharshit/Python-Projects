"""
API package initialization
"""
