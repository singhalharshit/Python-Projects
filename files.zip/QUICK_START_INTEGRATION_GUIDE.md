# 🚀 QUICK START: CRITICAL INTEGRATIONS

**Time Estimate:** 5 days (40 hours)  
**Impact:** Activates all dormant intelligence features  
**Priority:** CRITICAL

---

## 📋 INTEGRATION CHECKLIST

### Day 1: Safety Gates (8 hours)
- [x] Understand current state
- [ ] Add safety check before decision synthesis
- [ ] Create safety override decision method
- [ ] Update database schema
- [ ] Test all 5 gates
- [ ] Add API endpoint for safety status

### Day 2: Dynamic Niches (8 hours)
- [ ] Add niche storage in onboarding
- [ ] Create database migration
- [ ] Remove hardcoded niche references
- [ ] Test niche discovery
- [ ] Add niche API endpoints

### Day 3: Feedback Loop (8 hours)
- [ ] Enhance feedback endpoint
- [ ] Add pattern analysis endpoint
- [ ] Test learning cycle
- [ ] Validate preference updates

### Day 4: Vector Store (8 hours)
- [ ] Add periodic refresh task
- [ ] Populate on startup if empty
- [ ] Test similarity search
- [ ] Monitor performance

### Day 5: Integration Testing (8 hours)
- [ ] End-to-end onboarding test
- [ ] Decision generation test
- [ ] Learning cycle test
- [ ] Safety override test
- [ ] Fix any issues

---

## 🔧 IMPLEMENTATION GUIDE

### INTEGRATION 1: Safety Gates

#### File: `backend/app/services/decision_assistant.py`

**Location:** Line ~150 in `get_daily_decision()` method

**Before:**
```python
async def get_daily_decision(self, user_id: str) -> DailyDecision:
    logger.info(f"Generating daily decision for {user_id}")
    
    # Get creator embedding
    creator_data = self.vector_store.get_creator_embedding(user_id)
    # ... rest of method
```

**After:**
```python
async def get_daily_decision(self, user_id: str) -> DailyDecision:
    logger.info(f"Generating daily decision for {user_id}")
    
    # ✅ STEP 1: Import at top of file
    from app.services.intelligence.emotional_safety_system import EmotionalSafetySystem
    
    # ✅ STEP 2: Check safety gates FIRST
    safety_system = EmotionalSafetySystem(
        db=self.db,
        emotional_tracker=self.emotional_tracker
    )
    
    safety_check = safety_system.check_safety_gates(
        user_id=user_id,
        proposed_action='post'
    )
    
    # ✅ STEP 3: Handle safety override
    if not safety_check['safe']:
        logger.info(
            f"Safety override for {user_id}: "
            f"{safety_check['override_action']} "
            f"(severity: {safety_check['severity']})"
        )
        
        return self._create_safety_override_decision(
            user_id=user_id,
            safety_check=safety_check
        )
    
    # ✅ STEP 4: Add caution to normal decision if warnings
    if safety_check['gates_triggered']:
        logger.warning(
            f"Safety warnings for {user_id}: "
            f"{[g.rule_name for g in safety_check['gates_triggered']]}"
        )
    
    # Continue with normal synthesis...
    creator_data = self.vector_store.get_creator_embedding(user_id)
    # ... rest of existing code
```

**Add new method (at end of class):**
```python
def _create_safety_override_decision(
    self,
    user_id: str,
    safety_check: Dict
) -> DailyDecision:
    """
    Create a decision that overrides normal synthesis for safety.
    """
    action = safety_check['override_action']  # 'rest' or 'observe'
    
    # Get emotional context
    emotional_context = self.emotional_tracker.get_emotional_context(user_id)
    
    # Build metadata
    metadata = {
        'safety_override': True,
        'severity': safety_check['severity'],
        'gates_triggered': [
            {
                'rule': gate.rule_name,
                'severity': gate.severity,
                'explanation': gate.explanation
            }
            for gate in safety_check['gates_triggered']
        ]
    }
    
    # Create appropriate decision
    if action == 'rest':
        return DailyDecision(
            action='rest',
            topic=None,
            confidence=1.0,  # High confidence in safety decision
            explanation=safety_check['explanation'],
            emotional_context={
                'tone': 'protective',
                'reassurance': 'Your wellbeing comes first'
            },
            metadata=metadata
        )
    else:  # observe
        return DailyDecision(
            action='observe',
            topic=None,
            confidence=0.8,
            explanation=safety_check['explanation'],
            emotional_context={
                'tone': 'cautious',
                'reassurance': 'Better to watch and wait'
            },
            metadata=metadata
        )
```

**Test it:**
```bash
cd backend
python -c "
from app.core.database import SessionLocal
from app.services.decision_assistant import DecisionAssistant
import asyncio

db = SessionLocal()
assistant = DecisionAssistant(db)

# Test with a user
decision = asyncio.run(assistant.get_daily_decision('test_user_id'))
print(f'Action: {decision.action}')
print(f'Safety override: {decision.metadata.get(\"safety_override\", False)}')
"
```

---

### INTEGRATION 2: Dynamic Niche Storage

#### File: `backend/app/api/routes/onboarding.py`

**Location:** Line ~35 in `analyze_profile()` function

**Before:**
```python
@router.post("/analyze", response_model=OnboardingResponse)
async def analyze_profile(
    profile: ProfileData,
    db: Session = Depends(get_db)
):
    try:
        assistant = DecisionAssistant(db)
        
        result = await assistant.onboard_creator(
            user_id=profile.user_id,
            profile_data=profile.dict(),
            content_samples=profile.content_samples
        )
        
        return result
```

**After:**
```python
@router.post("/analyze", response_model=OnboardingResponse)
async def analyze_profile(
    profile: ProfileData,
    db: Session = Depends(get_db)
):
    try:
        assistant = DecisionAssistant(db)
        
        # ✅ STEP 1: Get onboarding result
        result = await assistant.onboard_creator(
            user_id=profile.user_id,
            profile_data=profile.dict(),
            content_samples=profile.content_samples
        )
        
        # ✅ STEP 2: Store dynamic niche in database
        if result.get('niche'):
            from app.models.dynamic_niche import DynamicNiche
            from app.models.user import User
            
            niche_data = result['niche']
            
            # Check if niche exists
            dynamic_niche = db.query(DynamicNiche).filter_by(
                id=niche_data['niche_id']
            ).first()
            
            if not dynamic_niche:
                # Create new niche
                dynamic_niche = DynamicNiche(
                    id=niche_data['niche_id'],
                    name=niche_data['label'],
                    embedding_centroid=niche_data['centroid'],
                    member_count=0,
                    is_micro=niche_data.get('is_micro', False),
                    descriptors=niche_data.get('descriptors', [])
                )
                db.add(dynamic_niche)
                logger.info(f"Created new niche: {dynamic_niche.name}")
            
            # Update member count
            dynamic_niche.member_count = db.query(User).filter_by(
                niche_id=niche_data['niche_id']
            ).count() + 1
            
            # ✅ STEP 3: Link user to niche
            user = db.query(User).filter_by(id=profile.user_id).first()
            if user:
                user.niche_id = niche_data['niche_id']
                logger.info(f"Linked user {profile.user_id} to niche {dynamic_niche.name}")
            
            db.commit()
        
        return result
        
    except Exception as e:
        db.rollback()
        logger.error(f"Onboarding failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
```

**Database Migration:**
```python
# Create migration file: alembic/versions/add_niche_id_to_users.py

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = 'add_niche_id'
down_revision = 'previous_revision'
branch_labels = None
depends_on = None

def upgrade():
    # Add niche_id column to users table
    op.add_column('users', sa.Column('niche_id', sa.String(64), nullable=True))
    op.create_foreign_key(
        'fk_users_niche_id',
        'users', 'dynamic_niches',
        ['niche_id'], ['id'],
        ondelete='SET NULL'
    )

def downgrade():
    op.drop_constraint('fk_users_niche_id', 'users', type_='foreignkey')
    op.drop_column('users', 'niche_id')
```

**Run migration:**
```bash
cd backend
alembic revision --autogenerate -m "add niche_id to users"
alembic upgrade head
```

**Test it:**
```bash
# Test onboarding with niche storage
curl -X POST http://localhost:8000/api/onboarding/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "test_user_123",
    "platform": "instagram",
    "bio": "Tech content creator passionate about AI and machine learning",
    "content_samples": [
      "Introduction to neural networks",
      "Python for beginners",
      "Latest AI trends"
    ]
  }'

# Check database
python -c "
from app.core.database import SessionLocal
from app.models.user import User
from app.models.dynamic_niche import DynamicNiche

db = SessionLocal()
user = db.query(User).filter_by(id='test_user_123').first()
if user and user.niche_id:
    niche = db.query(DynamicNiche).filter_by(id=user.niche_id).first()
    print(f'User niche: {niche.name}')
    print(f'Niche members: {niche.member_count}')
"
```

---

### INTEGRATION 3: Enhanced Feedback Loop

#### File: `backend/app/api/routes/actions.py`

**Location:** Replace the entire feedback endpoint

**Before:**
```python
@router.post("/{recommendation_id}/feedback")
async def record_feedback(...):
    # Basic implementation
    pass
```

**After:**
```python
from app.services.intelligence.feedback_loop import FeedbackLoop
from app.services.intelligence.preference_learner import PreferenceLearner
from app.services.intelligence.embedding_service import EmbeddingService
from datetime import datetime

@router.post("/{recommendation_id}/feedback")
async def record_feedback(
    recommendation_id: str,
    action: str,  # viewed, accepted, rejected, followed, ignored
    time_spent: Optional[int] = None,  # seconds
    context: Optional[Dict] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Record user action and update learning system.
    
    This endpoint is the core of the self-learning mechanism.
    """
    try:
        # ✅ STEP 1: Initialize feedback loop with all services
        feedback_loop = FeedbackLoop(
            db=db,
            preference_learner=PreferenceLearner(db),
            embedding_service=EmbeddingService()
        )
        
        # ✅ STEP 2: Build context
        full_context = context or {}
        if time_spent is not None:
            full_context['time_spent'] = time_spent
        full_context['timestamp'] = datetime.utcnow().isoformat()
        full_context['platform'] = 'web'  # or from request
        
        # ✅ STEP 3: Process action through feedback loop
        await feedback_loop.process_user_action(
            user_id=current_user.id,
            recommendation_id=recommendation_id,
            action=action,
            timestamp=datetime.utcnow(),
            context=full_context
        )
        
        logger.info(
            f"Processed {action} for user {current_user.id} "
            f"on recommendation {recommendation_id}"
        )
        
        # ✅ STEP 4: Analyze if preferences are changing
        pattern_change = await feedback_loop.analyze_pattern_changes(
            user_id=current_user.id,
            lookback_days=30
        )
        
        # ✅ STEP 5: Return learning insights
        return {
            "status": "processed",
            "action": action,
            "learning_status": {
                "interpretation": pattern_change.get('interpretation', 'stable'),
                "acceptance_rate": pattern_change.get('late_acceptance_rate', 0.0),
                "drift": pattern_change.get('drift', 0.0),
                "action_count": pattern_change.get('action_count', 0)
            }
        }
        
    except Exception as e:
        logger.error(f"Failed to process feedback: {e}")
        raise HTTPException(status_code=500, detail=str(e))
```

**Add new endpoint for insights:**
```python
@router.get("/me/learning-insights")
async def get_learning_insights(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    Get detailed learning insights for current user.
    """
    try:
        feedback_loop = FeedbackLoop(
            db=db,
            preference_learner=PreferenceLearner(db),
            embedding_service=EmbeddingService()
        )
        
        # ✅ Detect patterns
        time_pattern = await feedback_loop.detect_behavioral_patterns(
            current_user.id, 'time'
        )
        content_pattern = await feedback_loop.detect_behavioral_patterns(
            current_user.id, 'content'
        )
        mood_pattern = await feedback_loop.detect_behavioral_patterns(
            current_user.id, 'mood'
        )
        
        # ✅ Get preference stability
        pattern_analysis = await feedback_loop.analyze_pattern_changes(
            current_user.id, 30
        )
        
        return {
            "time_pattern": time_pattern,
            "content_pattern": content_pattern,
            "mood_pattern": mood_pattern,
            "preference_stability": pattern_analysis.get('interpretation'),
            "acceptance_rate": pattern_analysis.get('late_acceptance_rate', 0.0)
        }
        
    except Exception as e:
        logger.error(f"Failed to get insights: {e}")
        raise HTTPException(status_code=500, detail=str(e))
```

**Test it:**
```bash
# Test feedback recording
curl -X POST http://localhost:8000/api/actions/rec_123/feedback \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "action": "followed",
    "time_spent": 120,
    "context": {"platform": "instagram"}
  }'

# Test learning insights
curl -X GET http://localhost:8000/api/actions/me/learning-insights \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

### INTEGRATION 4: Vector Store Refresh

#### File: `backend/app/tasks/maintenance.py`

**Add this task:**
```python
from app.tasks.celery_app import celery_app
from app.core.database import SessionLocal
from app.models.creator import Creator
from app.services.intelligence.vector_store import get_vector_store
import numpy as np
import logging

logger = logging.getLogger(__name__)

@celery_app.task
def refresh_vector_store():
    """
    Refresh vector store with latest creator embeddings.
    
    This ensures competitor discovery uses up-to-date data.
    Runs daily at 2 AM.
    """
    logger.info("Starting vector store refresh")
    
    db = SessionLocal()
    try:
        # ✅ STEP 1: Get all creators with embeddings
        creators = db.query(Creator).filter(
            Creator.embedding.isnot(None)
        ).all()
        
        if not creators:
            logger.warning("No creators found with embeddings")
            return
        
        logger.info(f"Found {len(creators)} creators to index")
        
        # ✅ STEP 2: Extract embeddings and metadata
        embeddings = []
        ids = []
        metadata = []
        
        for creator in creators:
            embeddings.append(creator.embedding)
            ids.append(creator.id)
            metadata.append({
                'platform': creator.platform,
                'name': creator.name,
                'handle': creator.handle,
                'follower_count': creator.subscriber_count,
                'language': creator.language,
                'niche': creator.niche,
                'tags': creator.tags,
                'last_updated': creator.last_scraped.isoformat() if creator.last_scraped else None
            })
        
        # ✅ STEP 3: Rebuild index
        vector_store = get_vector_store()
        embedding_matrix = np.array(embeddings, dtype=np.float32)
        vector_store.build_index(embedding_matrix, ids, metadata)
        
        logger.info(f"Vector store refreshed with {len(ids)} creators")
        
    except Exception as e:
        logger.error(f"Failed to refresh vector store: {e}")
        raise
    finally:
        db.close()


@celery_app.task
def populate_vector_store_if_empty():
    """
    Populate vector store on first startup.
    """
    vector_store = get_vector_store()
    
    if vector_store.is_empty():
        logger.info("Vector store is empty, populating...")
        refresh_vector_store.apply_async()
    else:
        logger.info("Vector store already populated")
```

**Update startup (File: `backend/app/main.py`):**
```python
@app.on_event("startup")
async def startup_event():
    # ... existing code ...
    
    # ✅ NEW: Populate vector store if empty
    try:
        from app.tasks.maintenance import populate_vector_store_if_empty
        populate_vector_store_if_empty.apply_async()
    except Exception as e:
        logger.error(f"Failed to populate vector store: {e}")
```

**Test it:**
```bash
# Start Celery worker
celery -A app.tasks.celery_app worker --loglevel=info

# Trigger task manually
python -c "
from app.tasks.maintenance import refresh_vector_store
result = refresh_vector_store.apply_async()
print(f'Task ID: {result.id}')
"

# Check if vector store populated
python -c "
from app.services.intelligence.vector_store import get_vector_store
vs = get_vector_store()
print(f'Vector store size: {vs.get_size()}')
"
```

---

## 🧪 VALIDATION TESTS

### Test 1: Safety Gates Work
```python
# test_safety_integration.py
import asyncio
from app.core.database import SessionLocal
from app.services.decision_assistant import DecisionAssistant
from app.models.user import User
from app.models.user_action import UserAction
from datetime import datetime, timedelta

async def test_safety_gates():
    db = SessionLocal()
    
    # Create test user
    user = User(
        id='test_safety_user',
        email='test@example.com',
        password_hash='fake_hash'
    )
    db.add(user)
    
    # Simulate burnout scenario (7+ days of posting)
    for i in range(8):
        action = UserAction(
            user_id=user.id,
            recommendation_id=f'rec_{i}',
            action_type='followed',
            timestamp=datetime.utcnow() - timedelta(days=7-i)
        )
        db.add(action)
    
    db.commit()
    
    # Get decision
    assistant = DecisionAssistant(db)
    decision = await assistant.get_daily_decision(user.id)
    
    # Assert rest was suggested
    assert decision.action == 'rest', f"Expected 'rest', got '{decision.action}'"
    assert decision.metadata.get('safety_override') == True
    print("✅ Safety gates working!")
    
    db.close()

asyncio.run(test_safety_gates())
```

### Test 2: Dynamic Niches Work
```python
# test_niche_integration.py
from app.core.database import SessionLocal
from app.api.routes.onboarding import analyze_profile
from app.api.schemas import ProfileData
from app.models.dynamic_niche import DynamicNiche

async def test_niche_storage():
    db = SessionLocal()
    
    # Onboard user
    profile = ProfileData(
        user_id='test_niche_user',
        platform='instagram',
        bio='AI and machine learning content',
        content_samples=[
            'Neural networks explained',
            'Python for data science'
        ]
    )
    
    result = await analyze_profile(profile, db)
    
    # Check niche stored
    niche = db.query(DynamicNiche).filter_by(
        id=result['niche']['niche_id']
    ).first()
    
    assert niche is not None
    assert niche.name != ""
    print(f"✅ Niche stored: {niche.name}")
    
    db.close()

asyncio.run(test_niche_storage())
```

### Test 3: Feedback Loop Works
```python
# test_feedback_integration.py
import asyncio
from app.core.database import SessionLocal
from app.services.intelligence.feedback_loop import FeedbackLoop
from app.services.intelligence.preference_learner import PreferenceLearner
from app.services.intelligence.embedding_service import EmbeddingService
from app.models.recommendation import Recommendation
import numpy as np

async def test_feedback_learning():
    db = SessionLocal()
    
    # Create test recommendation
    rec = Recommendation(
        id='test_rec_123',
        user_id='test_user',
        date=datetime.utcnow().date(),
        topic='Test topic',
        reasoning='Test reasoning'
    )
    db.add(rec)
    db.commit()
    
    # Initialize feedback loop
    feedback_loop = FeedbackLoop(
        db=db,
        preference_learner=PreferenceLearner(db),
        embedding_service=EmbeddingService()
    )
    
    # Get initial preference
    initial_pref = feedback_loop.preference_learner.get_preference_vector('test_user')
    
    # Process action
    await feedback_loop.process_user_action(
        user_id='test_user',
        recommendation_id='test_rec_123',
        action='followed',
        context={'time_spent': 120}
    )
    
    # Get updated preference
    updated_pref = feedback_loop.preference_learner.get_preference_vector('test_user')
    
    # Assert preference changed
    assert not np.array_equal(initial_pref, updated_pref)
    print("✅ Feedback loop learning!")
    
    db.close()

asyncio.run(test_feedback_learning())
```

---

## 🚀 NEXT STEPS

After completing these integrations:

1. **Week 2:** Setup background jobs (Celery + Redis)
2. **Week 3-4:** Complete frontend features
3. **Week 5:** Comprehensive testing
4. **Week 6:** Production deployment

---

## 📞 TROUBLESHOOTING

### Safety Gates Not Triggering
```python
# Check emotional state
from app.services.intelligence.emotional_tracker import EmotionalStateTracker
from app.core.database import SessionLocal

db = SessionLocal()
tracker = EmotionalStateTracker(db)
state = tracker.get_current_state('your_user_id')
print(f"Burnout risk: {state.burnout_risk}")
```

### Niches Not Storing
```python
# Check migration
from alembic import command
from alembic.config import Config

config = Config("alembic.ini")
command.upgrade(config, "head")
```

### Feedback Not Learning
```python
# Check action records
from app.models.user_action import UserAction
from app.core.database import SessionLocal

db = SessionLocal()
actions = db.query(UserAction).filter_by(user_id='your_user_id').all()
print(f"Total actions: {len(actions)}")
for action in actions[-5:]:
    print(f"  - {action.action_type} at {action.timestamp}")
```

---

**Remember:** These integrations activate the most critical features. They transform your system from impressive components to a unified, emotionally intelligent assistant. 🎯
